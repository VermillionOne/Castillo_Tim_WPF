/**
 * Created by Vermillion on 12/12/14.
 */

// Functions - Anonymous Functions

var calcArea = function(width, height){ //defining
    //code the function runs
    var area = width * height;
    return area;
};

var a = calcArea(35, 20); //invoking

console.log(a);