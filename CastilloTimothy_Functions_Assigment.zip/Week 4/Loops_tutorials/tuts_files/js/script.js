/**
 * Created by Vermillion on 12/14/14.
 */

// Functions - While Loop


console.log('-------------- Loops --------------');

var b = 10;  //sets up the index

while (b > 0){ // Checks the condition
    console.log(b + " kegs on the wall" );
    b--; //increments or decrements the index
}

console.log('-------------- Do While Loops --------------');


var c = 10;

do{
    console.log(c + ' kegs on the wall');
    c--;
}
while(c > 0);

console.log('-------------- For Loops --------------');

for (var i = 10; i > 0; i --){
    console.log(i + ' kegs on the wall.')
}
