/*
 Tim Castillo
 SDI Section #03WDD
 Expressions_Industry Week #2
 12-05-2014
 */

//alert("Test");


//Cost of item
var itemCost = prompt("What is the purchasing cost of the item?");
//Sale price of item
var salePrice = prompt("What is the sale price of the item?");
//What is the promotional discount?
var discount = prompt("What is the promotional discount percentage?");
//What is the sales tax?
var salesTax = prompt("What is the sales tax?");
//Shipping and handling cost
var shippingCost = prompt("What is the cost of the shipping?");
//Discount applied to sale price
salePrice -= salePrice(100*discount);
//Tax applied to sale price
