/*
 Tim Castillo
 SDI Section #03WDD
 Expressions_Wacky Week #2
 12-05-2014
 */

//alert("Test");

//Number of collectors
var collectors = prompt("How many gold mines, elixir collectors, or dark elixir drills do you have?");
//Individual production rate of collectors
var productRate = prompt("How fast do they produce the material per hour?");
//Individual maximum capacity of collectors
var maxCapacity = prompt("How much can each collector hold?");
//Rate that the user manually collects the material
var userCollect = prompt("How many hours on average between collecting your materials?");
//Cost of item or upgrade
var itemCost = prompt("How much will it cost to upgrade or purchase your item?");
//




